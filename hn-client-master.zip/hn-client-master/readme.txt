Look at performance of load
Save the top 500 Stories instead of calling everytime
Check to make sure the page load doesnt go over 500
Spinner for loading not showing up 
Long load times
Bad looking OL and LI elements
Text in comments is exact and is not interruprted as markup as it should be

