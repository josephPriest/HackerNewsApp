import './styles.scss';

//Numerical Constants
const ARTICLES_PER_PAGE = 12;

//API Types
const GET = "GET";

//Tail URLS for HN
const JSON_PRETTY = ".json?print=pretty";
const TOP_STORIES = "topstories";
const ITEM = "item/";

var currentPage = 0;
//Event Listeners
function SetupEvents(){
  document.getElementById("moreButton").addEventListener ("click", MoreButton, false);
}

function ToggleLoader(turnOn){
  var x = document.getElementById('loadingBackground');
  if (turnOn) {
    console.log("Loading Called...");
      x.style.display = 'block';
  } else {
      x.style.display = 'none';
  }
}

function AddCommentToList(comment, parent){
  let newComment = document.createElement('li');
  newComment.appendChild(document.createTextNode(comment.text));
  parent.appendChild(newComment);
  return newComment;
}

function LoadComments(story, parent){
  if (story.kids != 'undefined' && story.kids.length > 0){
    for(let x = 0; x < story.kids.length; x++){
      MakeRequest(GET, ITEM + story.kids[x] + JSON_PRETTY).then(possibleComment => {
        if (possibleComment.type = "comment"){
          let newParent = AddCommentToList(possibleComment, parent);
          if(possibleComment.kids != 'undefined' && possibleComment.kids.length > 0 ){
            let newListForParent = document.createElement('ol');
            newParent.appendChild(newListForParent);
            LoadComments(possibleComment, newListForParent);
          }
        }
      });

    }
  }else {

  }
}

//Non-Async
function MoreButton(){
  currentPage++;
  GetTopStories();
}

async function ConstructArticleRow(articleData, position){
  let table = document.getElementById("articles");
  let row = table.insertRow(position);
  let cell = row.insertCell(0);
  MakeRequest(GET, ITEM + articleData + JSON_PRETTY).then(story => {
    cell.innerHTML = "<div class='articleLeft'> <img class='articleIcon' src='/src/images/articleIcon.png'> </div>\
                      <div class='articleRight'> <a class='articleTitle' href='"+ story.url + "'>" + story.title + " </a> <div id='" + story.id +"'  class='articleCommentsLink'>Comments</div>  </div>";
    document.getElementById(story.id).addEventListener("click", function(){
      let commentModal = document.getElementById('commentModal');
      document.getElementById('loadingBackground').style.display = 'block';
      commentModal.style.display = 'block';
      document.getElementById('close').onclick = function(){
          commentModal.style.display = 'none';
          document.getElementById("commentsList").innerHTML = '';
      };
      LoadComments(story, document.getElementById('commentsList'));
      document.getElementById('loadingBackground').style.display = 'none';

    }, false);

  });
}

//Async Calls
async function MakeRequest(requestType, endPath) {
  let xhttp = new XMLHttpRequest();
  xhttp.open(requestType, "https://hacker-news.firebaseio.com/v0/" + endPath, false);
  xhttp.setRequestHeader("Content-type", "application/json");
  xhttp.send();
  let response = JSON.parse(xhttp.responseText);
  return response;
}


async function GetTopStories(){
  document.getElementById('loadingBackground').style.display = 'block';
  MakeRequest(GET, TOP_STORIES + JSON_PRETTY).then(topStories => {
    let articleStart = ARTICLES_PER_PAGE * currentPage;
    let articleEnd = articleStart + ARTICLES_PER_PAGE;
    for(let x = articleStart; x < articleEnd; x++){
      ConstructArticleRow(topStories[x], x);
    }
    document.getElementById('loadingBackground').style.display = 'none';
  });
}

(async function startUp(){
    GetTopStories();
    SetupEvents();
})();
